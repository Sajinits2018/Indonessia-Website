import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Phone, Mail, MapPin, Clock } from 'lucide-react';
const Contact = () => {
  return <section id="contact" className="section-padding bg-care-gray-50 bg-white">
      <div className="container-width">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Take the Next Step To a Safer Infrastructure
          </h2>
          <p className="text-xl text-care-gray-600 text-blue-950">
            Let us plan your next upgrade together!
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12">
          <div>
            <Card className="bg-blue-200">
              <CardHeader className="bg-blue-200">
                <CardTitle>Schedule Your Consultation</CardTitle>
                <CardDescription>
                  Get expert electrical safety analysis for your Indonesian facility
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4 bg-blue-200">
                <div className="grid grid-cols-2 gap-4">
                  <Input placeholder="First Name" className="bg-[#fefeff]" />
                  <Input placeholder="Last Name" className="bg-white" />
                </div>
                <Input placeholder="Company" className="bg-white" />
                <Input placeholder="Email" type="email" className="bg-white" />
                <Input placeholder="Phone" type="tel" className="bg-white" />
                <Textarea placeholder="Tell us about your electrical system challenges..." rows={4} className="bg-white" />
                <Button className="w-full bg-care-blue-600 hover:bg-care-blue-700 text-white">
                  Request Consultation
                </Button>
              </CardContent>
            </Card>
          </div>
          
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-bold mb-6">Contact Information</h3>
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <Phone className="h-6 w-6 text-care-blue-600 rounded-xl bg-blue-100 px-[4px] py-[4px]" />
                  <div>
                    <div className="font-semibold text-black\n">Phone</div>
                    <div className="text-care-gray-600">+62 21 XXX XXXX</div>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <Mail className="h-6 w-6 text-care-blue-600 rounded-xl bg-blue-100 px-[4px] py-[4px]" />
                  <div>
                    <div className="font-semibold text-black\n">Email</div>
                    <div className="text-care-gray-600">info@carelabs.id</div>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <MapPin className="h-6 w-6 text-care-blue-600 px-[4px] py-[4px] bg-blue-100 rounded-xl" />
                  <div>
                    <div className="font-semibold text-black\n">Office</div>
                    <div className="text-care-gray-600">Jakarta, Indonesia</div>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <Clock className="h-6 w-6 text-care-blue-600 px-[4px] py-[4px] bg-blue-100 rounded-xl" />
                  <div>
                    <div className="font-semibold text-black\n">Business Hours</div>
                    <div className="text-care-gray-600">Monday - Friday: 9:00 AM - 6:00 PM WIB</div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-care-blue-50 p-6 rounded-lg">
              <h4 className="font-bold text-care-blue-900 mb-2">
                Emergency Electrical Safety Support
              </h4>
              <p className="text-care-blue-800 text-sm">
                For urgent electrical safety concerns, our emergency response team 
                is available 24/7 to provide immediate technical guidance and support.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>;
};
export default Contact;