import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, Zap, Shield, Wrench, BarChart3 } from 'lucide-react';
const Services = () => {
  const services = [{
    icon: Shield,
    title: "Compliance & Safety Support",
    description: "Safety audits, risk assessments, and regulatory compliance support",
    features: ["Safety Audits", "Risk Assessments", "Regulatory Compliance Support"]
  }, {
    icon: Wrench,
    title: "Technical Support",
    description: "Model development, technical documentation, and advanced ETAP analysis",
    features: ["Model Development", "Technical Documentation", "Advanced ETAP Analysis"]
  }, {
    icon: BarChart3,
    title: "Asset Lifecycle Management",
    description: "Preventive maintenance planning and upgrade recommendations",
    features: ["Asset Lifecycle Management", "Preventive Maintenance Planning", "Upgrade Recommendations"]
  }, {
    icon: Zap,
    title: "Performance Optimization",
    description: "Load management assistance and power quality analysis",
    features: ["Load Management Assistance", "Power Quality Analysis", "Performance Optimization"]
  }];
  return <section id="services" className="section-padding bg-care-gray-50">
      <div className="container-width">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Electrical Safety Solutions Built For Compliance & Efficiency
          </h2>
          <p className="text-xl text-care-gray-600 max-w-3xl mx-auto">
            Ensure the integrity of your electrical systems in Indonesia with Care Labs' 
            comprehensive power system analysis service suite. We offer tailored solutions 
            that not only meet global and local safety and compliance standards but also 
            provide tangible benefits throughout your system's lifecycle.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => <Card key={index} className="bg-blue-400">
              <CardHeader>
                <service.icon className="h-12 w-12 text-care-blue-600 mb-4 bg-zinc-50 px-[5px] py-[5px] rounded-3xl" />
                <CardTitle className="text-xl">{service.title}</CardTitle>
                <CardDescription>{service.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {service.features.map((feature, featureIndex) => <li key={featureIndex} className="flex items-center text-sm text-white\\n bg-[#000a0e]/0">
                      <CheckCircle className="py-[4px] px-[4px]" />
                      {feature}
                    </li>)}
                </ul>
              </CardContent>
            </Card>)}
        </div>
      </div>
    </section>;
};
export default Services;