import { Button } from '@/components/ui/button';
import { Zap, Shield, TrendingUp } from 'lucide-react';
const Hero = () => {
  return <section className="bg-gradient-to-r from-blue-800 via-blue-500 to-blue-300 text-white section-padding bg-blue-400">
      <div className="container-width">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="animate-fade-in">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 text-zinc-950">
              Power System Analysis That Turns Data Into Results
            </h1>
            <p className="text-xl mb-8 text-care-blue-100">
              At Care Labs, we provide electrical insights that transform your critical systems 
              from uncertainty to engineering clarity. More than just safety and compliance reports, 
              we deliver impactful solutions that drive your business forward.
            </p>
            <Button size="lg" className="bg-white text-care-blue-900 hover:bg-care-blue-50">
              Schedule a Consultation
            </Button>
            
            <div className="grid grid-cols-3 gap-8 mt-12">
              <div className="text-center">
                <Shield className="h-8 w-8 mx-auto mb-2" />
                <p className="text-sm">100% Compliance</p>
              </div>
              <div className="text-center">
                <Zap className="h-8 w-8 mx-auto mb-2" />
                <p className="text-sm">85% Safer Operations</p>
              </div>
              <div className="text-center">
                <TrendingUp className="h-8 w-8 mx-auto mb-2" />
                <p className="text-sm">23% Cost Reduction</p>
              </div>
            </div>
          </div>
          
          <div className="animate-slide-in">
            <img src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" alt="Electrical systems analysis" className="rounded-lg shadow-2xl" />
          </div>
        </div>
      </div>
    </section>;
};
export default Hero;