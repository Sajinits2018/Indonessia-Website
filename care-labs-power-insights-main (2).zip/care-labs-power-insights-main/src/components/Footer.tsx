const Footer = () => {
  return <footer className="bg-gradient-to-r from-blue-300 via-blue-500 to-blue-800 text-white section-padding">
      <div className="">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <div className="flex items-center mb-4 rounded-xl px-0">
              <img alt="Care Labs Indonesia" className="h-8 w-auto mr-3 object-fill" src="/lovable-uploads/a579840e-89f7-435c-a721-2bd87bc84da0.png" />
              <div>
                
                
              </div>
            </div>
            <p className="text-care-gray-300 mb-4">
              Care Labs, Indonesia, offers strategic electrical support from assessment to optimization, 
              driving business growth through comprehensive power system analysis.
            </p>
          </div>
          
          <div>
            <h4 className="font-bold mb-4 text-white">Services</h4>
            <ul className="space-y-2 text-care-gray-300">
              <li>Arc Flash Analysis</li>
              <li>Load Flow Studies</li>
              <li>Short Circuit Analysis</li>
              <li>Power Factor Correction</li>
              <li>Safety Audits</li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold mb-4 text-white">Standards</h4>
            <ul className="space-y-2 text-care-gray-300">
              <li>NFPA 70E</li>
              <li>IEEE Standards</li>
              <li>IEC 61439</li>
              <li>OSHA Guidelines</li>
              <li>Indonesian Regulations</li>
            </ul>
          </div>
        </div>
        
        <div className="">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-care-gray-300 text-sm">© 2025 Care Labs Indonesia. All rights reserved.</p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-care-gray-300 hover:text-white text-sm transition-colors">Privacy Policy</a>
              <a href="#" className="text-care-gray-300 hover:text-white text-sm transition-colors">Terms of Service</a>
              <a href="#" className="text-care-gray-300 hover:text-white text-sm transition-colors">Contact</a>
            </div>
          </div>
        </div>
      </div>
    </footer>;
};
export default Footer;