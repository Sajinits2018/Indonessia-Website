import { Menu, X } from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  return <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container-width">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center">
            <img alt="Care Labs Indonesia" src="/lovable-uploads/951db03c-e140-4f99-9ac9-ec7eb42b7b3d.png" className="h-10 w-100 mr-3" />
            <div>
              
              
            </div>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <a href="#services" className="text-care-gray-600 hover:text-care-blue-600 transition-colors">Home</a>
            <a href="#technology" className="text-care-gray-600 hover:text-care-blue-600 transition-colors">About Us</a>
            <a href="#about" className="text-care-gray-600 hover:text-care-blue-600 transition-colors">Our Services</a>
            <a href="#contact" className="text-care-gray-600 hover:text-care-blue-600 transition-colors">Contact</a>
          </nav>
          
          <div className="hidden md:block">
            <Button className="bg-gradient-to-r from-blue-300 via-blue-500 to-blue-800 text-white section-padding">
              Schedule Consultation
            </Button>
          </div>
          
          <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
        
        {isMenuOpen && <div className="md:hidden pb-4">
            <nav className="flex flex-col space-y-4">
              <a href="#services" className="text-care-gray-600 hover:text-care-blue-600">Services</a>
              <a href="#technology" className="text-care-gray-600 hover:text-care-blue-600">Technology</a>
              <a href="#about" className="text-care-gray-600 hover:text-care-blue-600">About</a>
              <a href="#contact" className="text-care-gray-600 hover:text-care-blue-600">Contact</a>
              <Button className="bg-care-blue-600 hover:bg-care-blue-700 w-full">
                Schedule Consultation
              </Button>
            </nav>
          </div>}
      </div>
    </header>;
};
export default Header;