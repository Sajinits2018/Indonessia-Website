import { TrendingUp, Shield, DollarSign, CheckCircle } from 'lucide-react';
const Impact = () => {
  const metrics = [{
    icon: CheckCircle,
    value: "100%",
    label: "Compliance Success",
    description: "Perfect track record in meeting safety standards"
  }, {
    icon: Shield,
    value: "85%",
    label: "Safer Operations",
    description: "Reduction in electrical safety incidents"
  }, {
    icon: DollarSign,
    value: "23%",
    label: "Reduced Energy Costs",
    description: "Average cost savings through optimization"
  }, {
    icon: TrendingUp,
    value: "99.9%",
    label: "System Reliability",
    description: "Uptime improvement across client facilities"
  }];
  return <section className="bg-gradient-to-r from-blue-800 via-blue-500 to-blue-300 text-white section-padding bg-blue-500">
      <div className="container-width">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            We Turn Electrical Risks Into Strategic Advantage
          </h2>
          <p className="text-xl text-care-gray-600 max-w-3xl mx-auto text-slate-50">
            Align your long-term business vision with the operational reliability of your power systems. 
            With Care Labs' proven approach and technical excellence, you can expect measurable impacts 
            in safety, efficiency, and ROI.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {metrics.map((metric, index) => <div key={index} className="text-center">
              <div className="bg-care-blue-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <metric.icon className="h-8 w-8 text-care-blue-600" />
              </div>
              <div className="text-4xl font-bold text-care-white-600 mb-2">{metric.value}</div>
              <div className="text-lg font-semibold mb-2">{metric.label}</div>
              <p className="text-care-white-600 text-sm">{metric.description}</p>
            </div>)}
        </div>
      </div>
    </section>;
};
export default Impact;