import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Cpu, FileCheck, Globe, Award } from 'lucide-react';
const Technology = () => {
  const standards = [{
    name: "NFPA",
    description: "National Fire Protection Association"
  }, {
    name: "IEEE",
    description: "Institute of Electrical and Electronics Engineers"
  }, {
    name: "IEC",
    description: "International Electrotechnical Commission"
  }, {
    name: "Local Regulations",
    description: "Indonesian electrical standards"
  }];
  return <section id="technology" className="section-padding bg-care-gray-50">
      <div className="container-width">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Precision Analytics With ETAP Power System Software
            </h2>
            <p className="text-lg text-care-gray-600 mb-8 text-zinc-950">
              At Care Labs, we utilize high-fidelity power system analysis software—ETAP. 
              Our expert team delivers performance insights that comply with standards such as 
              NFPA, IEEE, IEC, and local regulations.
            </p>
            
            <div className="grid grid-cols-2 gap-4 mb-8">
              {standards.map((standard, index) => <div key={index} className="flex items-center space-x-3">
                  <Award className="h-5 w-5 text-care-blue-600 flex-shrink-0 bg-blue-100 px-[2px] py-[2px] rounded-2xl" />
                  <div>
                    <div className="font-semibold text-black\n">{standard.name}</div>
                    <div className="text-sm text-black bg-slate-50\n">{standard.description}</div>
                  </div>
                </div>)}
            </div>
          </div>
          
          <div className="grid gap-6">
            <Card>
              <CardHeader className="bg-gradient-to-r from-blue-500 to-white rounded-xl\n">
                <Cpu className="h-8 w-8 text-care-blue-600 mb-2 bg-slate-50 rounded-xl px-[5px] py-[5px]" />
                <CardTitle>Advanced Modeling</CardTitle>
                <CardDescription>
                  High-fidelity power system modeling and simulation
                </CardDescription>
              </CardHeader>
            </Card>
            
            <Card>
              <CardHeader className="bg-blue-500 rounded-xl">
                <FileCheck className="h-8 w-8 text-care-blue-600 mb-2 bg-slate-50 rounded-xl px-[5px] py-[5px]" />
                <CardTitle>Compliance Reporting</CardTitle>
                <CardDescription>
                  Comprehensive reports meeting international standards
                </CardDescription>
              </CardHeader>
            </Card>
            
            <Card>
              <CardHeader className="bg-blue-500 rounded-xl">
                <Globe className="h-8 w-8 text-care-blue-600 mb-2 bg-slate-50 rounded-xl px-[5px] py-[5px]" />
                <CardTitle>Global Standards</CardTitle>
                <CardDescription>
                  NFPA, IEEE, IEC, and local regulatory compliance
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </div>
    </section>;
};
export default Technology;