import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Zap, Shield, FileText, TrendingDown } from 'lucide-react';
const Solutions = () => {
  const solutions = [{
    icon: TrendingDown,
    title: "Poor Power Factor Issues",
    problem: "Is a poor power factor affecting your energy costs and equipment efficiency?",
    solution: "Improve it with Care Labs' targeted correction strategies through comprehensive Load Flow Analysis and power quality assessments tailored for your business."
  }, {
    icon: Shield,
    title: "Protection Strategy Concerns",
    problem: "Are improper protection strategies concerning you about equipment damage during faults?",
    solution: "Our short circuit analysis and relay coordination studies can help implement the right protection strategies."
  }, {
    icon: FileText,
    title: "Outdated Documentation",
    problem: "Are outdated documents and reports jeopardizing your electrical safety compliance?",
    solution: "Care Labs provides comprehensive reports and solutions that align with compliance standards, including IEEE, IEC, NFPA, and OSHA guidelines."
  }];
  return <section className="bg-gradient-to-r from-blue-800 via-blue-500 to-blue-300 text-white section-padding">
      <div className="container-width">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-slate-50">
            We Don't Just Stop At Analysis, We Solve
          </h2>
          <p className="text-xl text-care-gray-600 max-w-3xl mx-auto text-slate-50">
            Transform your electrical challenges into strategic advantages with our targeted solutions.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-3 gap-8">
          {solutions.map((solution, index) => <Card key={index} className="hover:shadow-lg transition-shadow duration-300 h-full bg-slate-50">
              <CardHeader>
                <solution.icon className="h-12 w-12 text-care-blue-600 mb-4 bg-blue-100 rounded-xl px-[10px] py-[10px]" />
                <CardTitle className="text-xl">{solution.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="mb-4 font-medium text-black\n">{solution.problem}</p>
                <p className="text-care-gray-800">{solution.solution}</p>
              </CardContent>
            </Card>)}
        </div>
      </div>
    </section>;
};
export default Solutions;