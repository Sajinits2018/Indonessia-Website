
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import Services from '@/components/Services';
import Impact from '@/components/Impact';
import Technology from '@/components/Technology';
import Solutions from '@/components/Solutions';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';

const Index = () => {
  return (
    <div className="min-h-screen">
      <Header />
      <Hero />
      <Services />
      <Impact />
      <Technology />
      <Solutions />
      <Contact />
      <Footer />
    </div>
  );
};

export default Index;
